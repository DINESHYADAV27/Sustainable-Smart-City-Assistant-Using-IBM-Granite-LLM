from flask import Flask, render_template, request, jsonify
from modules import summarizer, route_recommender, feedback_analyzer, ev_optimizer, kpi_forecaster, anomaly_detector, chatbot

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/summarize', methods=['POST'])
def summarize_traffic():
    file = request.files['file']
    summary = summarizer.summarize_csv(file)
    return jsonify({"summary": summary})

@app.route('/eco_route', methods=['POST'])
def eco_route():
    data = request.get_json()
    route = route_recommender.recommend(data)
    return jsonify({"route": route})

@app.route('/analyze_feedback', methods=['POST'])
def analyze_feedback():
    text = request.form['feedback']
    result = feedback_analyzer.analyze(text)
    return jsonify(result)

@app.route('/optimize_ev', methods=['POST'])
def optimize_ev():
    data = request.get_json()
    placements = ev_optimizer.optimize(data)
    return jsonify({"placements": placements})

@app.route('/forecast_kpi', methods=['POST'])
def forecast_kpi():
    data = request.get_json()
    forecast = kpi_forecaster.forecast(data)
    return jsonify(forecast)

@app.route('/detect_anomalies', methods=['POST'])
def detect_anomalies():
    data = request.get_json()
    anomalies = anomaly_detector.detect(data)
    return jsonify(anomalies)

@app.route('/chat', methods=['POST'])
def chat():
    query = request.form['query']
    response = chatbot.ask(query)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
import pandas as pd

def summarize_csv(file):
    df = pd.read_csv(file)
    summary = {
        "total_rows": len(df),
        "columns": list(df.columns),
        "mean_values": df.mean(numeric_only=True).to_dict()
    }
    return summary